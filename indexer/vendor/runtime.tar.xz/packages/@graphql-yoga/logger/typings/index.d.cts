export declare const ansiCodes: {
    readonly red: '\u001B[31m';
    readonly yellow: '\u001B[33m';
    readonly magenta: '\u001B[35m';
    readonly cyan: '\u001B[36m';
    readonly reset: '\u001B[0m';
};
export declare const warnPrefix: string;
export declare const infoPrefix: string;
export declare const errorPrefix: string;
export declare const debugPrefix: string;
export type LogLevel = 'debug' | 'info' | 'warn' | 'error';
export type YogaLogger = Record<LogLevel, (...args: any[]) => void>;
export declare const createLogger: (logLevel?: LogLevel | 'silent') => YogaLogger;
