import { GraphQLFieldResolver } from 'graphql';
import { GraphQLResolveInfo, Maybe } from '@graphql-tools/utils';
export declare function chainResolvers<TArgs extends {
    [argName: string]: any;
}>(resolvers: Array<Maybe<GraphQLFieldResolver<any, any, TArgs>>>): (root: any, args: TArgs, ctx: any, info: GraphQLResolveInfo) => any;
